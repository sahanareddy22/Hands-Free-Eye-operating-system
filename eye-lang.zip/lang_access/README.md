# Language-Independent Access Feature

This folder contains a demo/module that provides language-independent access:
- Universal-symbol UI (icons)
- Browser voice recognition (Web Speech API)
- Server-side ASR endpoint (OpenAI Whisper example)
- AI translation endpoint (OpenAI Chat example, with fallback)

How to use:
1. From your project root, install dependencies (see requirements file added to project).
2. Run your main app and mount this module at '/lang_access' OR run this module standalone:
   python lang_access/app.py
3. Set OPENAI_API_KEY in environment to enable OpenAI features.
