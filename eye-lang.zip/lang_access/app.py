
import os
import io
import zipfile
import tempfile
import asyncio
from fastapi import FastAPI, Request, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
import openai

try:
    from langdetect import detect
except Exception:
    def detect(text): return 'und'

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY

app = FastAPI(title="Language-Independent Access Feature")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

DEFAULT_TARGET = "en"

@app.get("/", response_class=HTMLResponse)
async def index():
    html = \"\"\"<!doctype html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Language-Independent Access</title>
<style>
:root{--accent:#1976d2;--bg:#fff;--text:#111}
body{font-family:system-ui,Segoe UI,Roboto,Arial;margin:18px;background:var(--bg);color:var(--text)}
.card{max-width:900px;margin:auto;padding:18px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,0.08)}
.controls{display:flex;gap:10px;align-items:center}
button{padding:10px;border-radius:10px;border:0;background:var(--accent);color:#fff;cursor:pointer}
.icon{width:36px;height:36px;vertical-align:middle}
textarea{width:100%;height:120px;padding:10px;border-radius:8px;border:1px solid #ddd}
.output{white-space:pre-wrap;margin-top:12px}
</style>
</head><body>
<div class="card">
<h2>Language-Independent Access (Feature)</h2>
<p>Universal symbols + voice recognition + AI translation (OpenAI). Works as a demo module you can integrate.</p>
<div class="controls">
  <button id="btn-speak" title="Voice input"><svg class="icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 14a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v5a3 3 0 0 0 3 3z" stroke="white" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg> Voice</button>
  <button id="btn-upload">Upload audio</button>
  <button id="btn-translate">Translate</button>
  <button id="btn-play">Listen</button>
  <select id="target-lang"><option value="en">English</option><option value="es">Español</option><option value="hi">हिन्दी</option><option value="fr">Français</option><option value="zh-CN">中文</option></select>
</div>
<textarea id="text-input" placeholder="Type or speak here"></textarea>
<div class="output"><h4>Translated</h4><pre id="translated-text">(none)</pre></div>
<input id="file-input" type="file" accept="audio/*" style="display:none" />
<script>
let recognition = null; let recognizing=false; let lastTranslated='';
if (window.webkitSpeechRecognition || window.SpeechRecognition) {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  recognition.lang='auto'; recognition.interimResults=true; recognition.continuous=false;
  recognition.onstart = ()=> recognizing=true; recognition.onend=()=> recognizing=false;
  recognition.onresult = (e)=>{
    let interim=''; let final='';
    for (let i=e.resultIndex;i<e.results.length;i++){ const r=e.results[i]; if (r.isFinal) final+=r[0].transcript; else interim+=r[0].transcript; }
    document.getElementById('text-input').value = final || interim;
  };
} else { document.getElementById('btn-speak').disabled=true; document.getElementById('btn-speak').title='Speech recognition not supported'; }

document.getElementById('btn-speak').addEventListener('click', ()=>{ if (!recognition) return alert('No speech recognition'); if (recognizing) recognition.stop(); else recognition.start(); });
document.getElementById('btn-upload').addEventListener('click', ()=> document.getElementById('file-input').click());
document.getElementById('file-input').addEventListener('change', async (ev)=>{
  const f = ev.target.files[0]; if (!f) return; const fd = new FormData(); fd.append('file', f);
  const res = await fetch('/lang_access/asr',{method:'POST', body:fd}); const j = await res.json();
  if (j.transcript) document.getElementById('text-input').value = j.transcript;
  else alert('ASR failed: '+(j.error||'unknown'));
});

document.getElementById('btn-translate').addEventListener('click', async ()=>{
  const text = document.getElementById('text-input').value.trim(); if (!text) return alert('Type or speak something');
  const target = document.getElementById('target-lang').value;
  const res = await fetch('/lang_access/translate',{method:'POST',headers:{'Content-Type':'application/json'},body: JSON.stringify({text,text, target_lang: target})});
  const j = await res.json();
  if (j.translated_text) {
    document.getElementById('translated-text').textContent = j.translated_text;
    lastTranslated = j.translated_text;
  } else alert('Translate error: '+(j.error||'unknown'));
});

document.getElementById('btn-play').addEventListener('click', ()=>{
  if (!lastTranslated) return alert('No text to play'); const u = new SpeechSynthesisUtterance(lastTranslated); u.lang = document.getElementById('target-lang').value; window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
});
</script>
</div></body></html>