
from fastapi import APIRouter, UploadFile, File
from fastapi.responses import JSONResponse
import os, tempfile
router = APIRouter()

try:
    import openai
    OPENAI = True
except Exception:
    OPENAI = False

try:
    from langdetect import detect
except Exception:
    def detect(text): return 'und'

@router.post("/translate")
async def translate(req: dict):
    text = req.get("text","")
    target = req.get("target_lang","en")
    src = detect(text) if text else 'und'
    if OPENAI and os.getenv("OPENAI_API_KEY"):
        try:
            openai.api_key = os.getenv("OPENAI_API_KEY")
            # Use OpenAI's Chat API for translation; keeping simple
            resp = openai.ChatCompletion.create(model="gpt-3.5-turbo", messages=[{"role":"system","content":"You are a translator. Output only the translated text."},{"role":"user","content":f"Translate to {target}: {text}"}], temperature=0.0)
            translated = resp.choices[0].message.content.strip()
            return JSONResponse({"translated_text": translated, "src": src})
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)
    # fallback: return original text
    return JSONResponse({"translated_text": text, "src": src})

@router.post("/asr")
async def asr(file: UploadFile = File(...)):
    contents = await file.read()
    if OPENAI and os.getenv("OPENAI_API_KEY"):
        # write temp file and call OpenAI Whisper (pseudo code; actual SDK call may differ)
        with tempfile.NamedTemporaryFile(delete=False, suffix="."+ (file.filename.split(".")[-1] or "wav")) as t:
            t.write(contents); tmp = t.name
        try:
            # Note: depending on openai client version, API may differ.
            audio_file = open(tmp, "rb")
            resp = openai.Audio.transcriptions.create(file=audio_file, model="whisper-1")
            text = resp.get("text","")
            return JSONResponse({"transcript": text})
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)
        finally:
            try: os.unlink(tmp)
            except: pass
    return JSONResponse({"error":"ASR not configured (OpenAI API key missing)."}, status_code=500)
